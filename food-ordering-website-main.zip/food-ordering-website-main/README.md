# food-ordering-website
This is a food ordering website using HTML, CSS, JAVASCRIPT
